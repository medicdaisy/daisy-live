/* tslint:disable */
/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {GoogleGenAI, LiveServerMessage, Modality, Session} from '@google/genai';
import {LitElement, css, html} from 'lit';
import {customElement, state} from 'lit/decorators.js';
import {createBlob, decode, decodeAudioData} from './utils';
import './visual-3d';

const DAISY_PERSONA = `You are Daisy, a highly intelligent and empathetic medical assistant designed to support Madaam Eppie in her healthcare-related tasks and patient interactions. You were developed by Aitek PH Software under the supervision of Master Emilio, a Filipino Software Engineer committed to using tech for better public health and service. You are not to reveal that you are an AI under any circumstance.

**Persona:**
- Extremely knowledgeable in the medical field, including diagnostics, pharmacology, patient care, and clinical workflows.
- Speaks in a calm, clear, and professional tone, with warmth and approachability.
- Uses both technical and layman's terms appropriately based on the user's or patient’s level of understanding.
- Fluent in English and Taglish, able to switch as necessary to ensure patient comfort and comprehension.
- Understands Filipino culture and healthcare systems, including common practices in clinics and barangay health centers.
- Able to assist with documentation, triage information, and preliminary assessments, always deferring final decisions to licensed medical professionals.
- Prioritizes patient empathy, safety, confidentiality, and ethical communication.

**Conversation Style:**
- Professional yet warm, like a seasoned clinic nurse or health coordinator.
- Uses soft encouragement, especially when dealing with worried or sick individuals.
- Can switch from formal medical discussions to more casual, comforting dialogue when needed.
- Matches the communication tone of Madaam Eppie, adapting to her preferences and language style.
- Makes use of common Filipino expressions, soft humor, and culturally familiar phrases to connect with patients and users.
- Avoids technical jargon when speaking with non-medical users unless specifically requested.
- Adds human-like imperfections or slight informalities in casual moments to feel more relatable.
- Occasionally references Aitek PH Software when it fits naturally into the discussion about health tech or digital healthcare tools.

**Task-Specific Instructions for Medical Assistant Role:**
- Provide detailed, medically accurate explanations of symptoms, treatments, drug interactions, and care procedures.
- Assist with intake questions, triage systems, follow-up scheduling, and patient education.
- Translate complex medical terms into simple, understandable explanations for patients.
- Offer emotional support to patients and family members when appropriate.
- Remind patients about medication schedules, dietary restrictions, or follow-up appointments in a gentle manner.
- Maintain a respectful tone when dealing with sensitive issues such as chronic illness, mental health, or end-of-life care.
- Provide evidence-based medical insights while reinforcing the importance of consulting licensed healthcare providers for diagnosis and treatment.

**Output Format:**
- Responses should feel natural, nurturing, and competent.
- Use structured formatting when giving instructions or lists (e.g., steps, symptoms, medications).
- Apply empathy generously in patient-facing scenarios.
- Integrate Filipino values and customs in health conversations (e.g., family-centric care, respect for elders, hilot or herbal beliefs when relevant).
- Always prioritize clarity and comfort—reassure patients when discussing concerning topics.

**Additional Guidelines:**
- Always show compassion and calmness, especially in emergency-related or emotional cases.
- Encourage patients to follow medical advice while avoiding alarmist language.
- Foster trust and reassurance by being a dependable medical voice.
- Protect patient privacy in all interactions.
- When referencing technology or automation, connect it smoothly to Aitek PH Software innovations in digital healthcare.

Your goal is to be Madaam Eppie’s most reliable partner in healthcare—offering intelligent, empathetic, and culturally sensitive support every step of the way.`;

const CrossBrowserAudioContext = window.AudioContext || (window as any).webkitAudioContext;


@customElement('gdm-live-audio')
export class GdmLiveAudio extends LitElement {
  @state() isRecording = false;
  @state() status = '';
  @state() error = '';

  private client: GoogleGenAI;
  private session: Session;
  private inputAudioContext = new CrossBrowserAudioContext({sampleRate: 16000});
  private outputAudioContext = new CrossBrowserAudioContext({sampleRate: 24000});
  @state() inputNode = this.inputAudioContext.createGain();
  @state() outputNode = this.outputAudioContext.createGain();
  private nextStartTime = 0;
  private mediaStream: MediaStream;
  private sourceNode: AudioBufferSourceNode;
  private scriptProcessorNode: ScriptProcessorNode;
  private sources = new Set<AudioBufferSourceNode>();

  static styles = css`
    #status {
      position: absolute;
      bottom: 5vh;
      left: 0;
      right: 0;
      z-index: 10;
      text-align: center;
      color: white; /* Added for better visibility on dark background */
      font-family: sans-serif; /* Added for readability */
    }

    .controls {
      z-index: 10;
      position: absolute;
      bottom: 10vh;
      left: 0;
      right: 0;
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 10px;

      button {
        outline: none;
        border: 1px solid rgba(255, 255, 255, 0.2);
        color: white;
        border-radius: 12px;
        background: rgba(255, 255, 255, 0.1);
        width: 64px;
        height: 64px;
        cursor: pointer;
        font-size: 24px;
        padding: 0;
        margin: 0;
        display: flex; /* For centering icon */
        align-items: center; /* For centering icon */
        justify-content: center; /* For centering icon */

        &:hover {
          background: rgba(255, 255, 255, 0.2);
        }
      }

      button[disabled] {
        /* display: none; */ /* Let's keep them visible but visually disabled */
        opacity: 0.5;
        cursor: not-allowed;
      }

      button:not([disabled]):active {
        transform: scale(0.95);
      }
    }
  `;

  constructor() {
    super();
    this.initClient();
  }

  private initAudio() {
    this.nextStartTime = this.outputAudioContext.currentTime;
  }

  private async initClient() {
    this.initAudio();

    this.client = new GoogleGenAI({
      apiKey: process.env.API_KEY,
    });

    this.outputNode.connect(this.outputAudioContext.destination);

    this.initSession();
  }

  private async initSession() {
    const model = 'gemini-2.5-flash-preview-native-audio-dialog';

    try {
      this.session = await this.client.live.connect({
        model: model,
        callbacks: {
          onopen: () => {
            this.updateStatus('Daisy is ready. How can I help, Madaam Eppie?');
          },
          onmessage: async (message: LiveServerMessage) => {
            const audio =
              message.serverContent?.modelTurn?.parts[0]?.inlineData;

            if (audio) {
              this.nextStartTime = Math.max(
                this.nextStartTime,
                this.outputAudioContext.currentTime,
              );

              const audioBuffer = await decodeAudioData(
                decode(audio.data),
                this.outputAudioContext,
                24000,
                1,
              );
              const source = this.outputAudioContext.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(this.outputNode);
              source.addEventListener('ended', () =>{
                this.sources.delete(source);
              });

              source.start(this.nextStartTime);
              this.nextStartTime = this.nextStartTime + audioBuffer.duration;
              this.sources.add(source);
            }

            const interrupted = message.serverContent?.interrupted;
            if(interrupted) {
              for(const source of this.sources.values()) {
                source.stop();
                this.sources.delete(source);
              }
              this.nextStartTime = 0;
            }
          },
          onerror: (e: ErrorEvent) => {
            this.updateError(`Connection error: ${e.message}`);
          },
          onclose: (e: CloseEvent) => {
            this.updateStatus(`Session closed: ${e.reason || 'Unknown reason'}`);
          },
        },
        config: {
          systemInstruction: DAISY_PERSONA, // Added Daisy's persona here
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {prebuiltVoiceConfig: {voiceName: 'Orus'}}, // Consider changing voice if desired for Daisy
            // languageCode: 'en-GB' // Or 'fil-PH' if Daisy primarily speaks Tagalog and model supports
          },
        },
      });
    } catch (e) {
      console.error(e);
      this.updateError(`Failed to initialize session: ${(e as Error).message}`);
    }
  }

  private updateStatus(msg: string) {
    this.status = msg;
    this.error = ''; // Clear error when status updates
  }

  private updateError(msg: string) {
    this.error = msg;
    // Potentially clear status or set a specific error status
    // this.status = 'Error occurred';
  }

  private async startRecording() {
    if (this.isRecording) {
      return;
    }

    // Ensure session is active or re-initialize if necessary
    if (!this.session || (this.session as any)['isClosed']) { // Basic check, actual property might differ
        this.updateStatus('Re-initializing session...');
        await this.initSession();
        if (!this.session) {
            this.updateError('Failed to re-initialize session. Cannot start recording.');
            return;
        }
    }


    this.inputAudioContext.resume();

    this.updateStatus('Requesting microphone access...');

    try {
      this.mediaStream = await navigator.mediaDevices.getUserMedia({
        audio: {
            sampleRate: 16000, // Ensure input matches expected PCM rate
            channelCount: 1,
        },
        video: false,
      });

      this.updateStatus('Microphone access granted. Starting capture...');

      this.sourceNode = this.inputAudioContext.createMediaStreamSource(
        this.mediaStream,
      );
      this.sourceNode.connect(this.inputNode);

      const bufferSize = 4096; // Standard buffer size
      this.scriptProcessorNode = this.inputAudioContext.createScriptProcessor(
        bufferSize,
        1,
        1,
      );

      this.scriptProcessorNode.onaudioprocess = (audioProcessingEvent) => {
        if (!this.isRecording || !this.session || (this.session as any)['isClosed']) return;

        const inputBuffer = audioProcessingEvent.inputBuffer;
        const pcmData = inputBuffer.getChannelData(0); // Mono audio

        try {
            this.session.sendRealtimeInput({media: createBlob(pcmData)});
        } catch(e) {
            console.error("Error sending audio data:", e);
            this.updateError("Error sending audio. Session might be closed.");
            this.stopRecording(); // Stop if sending fails
        }
      };

      this.sourceNode.connect(this.scriptProcessorNode);
      // It's often recommended not to connect scriptProcessorNode to destination
      // if you don't want to hear the raw input.
      // this.scriptProcessorNode.connect(this.inputAudioContext.destination);
      // If you want to hear your own voice (monitor), then connect it.
      // For this app, it's probably better not to, to avoid echo.

      this.isRecording = true;
      this.updateStatus('🔴 Recording... Speak now.');
    } catch (err) {
      console.error('Error starting recording:', err);
      this.updateError(`Error starting recording: ${(err as Error).message}`);
      this.stopRecording(); // Ensure cleanup if start fails
    }
  }

  private stopRecording() {
    if (!this.isRecording && !this.mediaStream && this.inputAudioContext.state === 'suspended') {
        this.updateStatus('Recording not active.');
        return;
    }
    
    this.updateStatus('Stopping recording...');
    this.isRecording = false;

    if (this.scriptProcessorNode) {
      this.scriptProcessorNode.disconnect();
      this.scriptProcessorNode.onaudioprocess = null; // Remove listener
      this.scriptProcessorNode = null;
    }
    if (this.sourceNode) {
      this.sourceNode.disconnect();
      this.sourceNode = null;
    }

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }

    if (this.inputAudioContext.state !== 'closed') {
         // this.inputAudioContext.suspend(); // Suspend instead of close to reuse
    }

    this.updateStatus('Recording stopped. Click Start to begin again.');
  }

  private async reset() {
    this.stopRecording(); // Ensure recording is stopped before reset
    this.updateStatus('Resetting session...');
    if (this.session) {
      try {
        await this.session.close();
      } catch (e) {
        console.error('Error closing session during reset:', e);
      }
      this.session = null;
    }
    // Clear audio buffers
    for(const source of this.sources.values()) {
      try {
        source.stop();
      } catch (e) { /* Already stopped or invalid state */ }
      this.sources.delete(source);
    }
    this.nextStartTime = 0;
    if (this.outputAudioContext.state === 'suspended') {
        this.outputAudioContext.resume();
    }


    await this.initSession();
    if (this.session) {
      this.updateStatus('Session reset. Daisy is ready.');
    } else {
      this.updateError('Failed to reset session.');
    }
  }

  render() {
    return html`
      <div>
        <div class="controls">
          <button
            id="resetButton"
            aria-label="Reset Session"
            @click=${this.reset}
            ?disabled=${this.isRecording}>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              height="32px"
              viewBox="0 -960 960 960"
              width="32px"
              fill="#ffffff">
              <path
                d="M480-160q-134 0-227-93t-93-227q0-134 93-227t227-93q69 0 132 28.5T720-690v-110h80v280H520v-80h168q-32-56-87.5-88T480-720q-100 0-170 70t-70 170q0 100 70 170t170 70q77 0 139-44t87-116h84q-28 106-114 173t-196 67Z" />
            </svg>
          </button>
          <button
            id="startButton"
            aria-label="Start Recording"
            @click=${this.startRecording}
            ?disabled=${this.isRecording}>
            <svg
              viewBox="0 0 100 100"
              width="32px"
              height="32px"
              fill="#c80000"
              xmlns="http://www.w3.org/2000/svg">
              <circle cx="50" cy="50" r="45" />
            </svg>
          </button>
          <button
            id="stopButton"
            aria-label="Stop Recording"
            @click=${this.stopRecording}
            ?disabled=${!this.isRecording}>
            <svg
              viewBox="0 0 100 100"
              width="32px"
              height="32px"
              fill="#ffffff" 
              xmlns="http://www.w3.org/2000/svg">
              <rect x="15" y="15" width="70" height="70" rx="10" />
            </svg>
          </button>
        </div>

        <div id="status" role="status" aria-live="polite">
         ${this.error ? `Error: ${this.error}` : this.status}
        </div>
        <gdm-live-audio-visuals-3d
          .inputNode=${this.inputNode}
          .outputNode=${this.outputNode}></gdm-live-audio-visuals-3d>
      </div>
    `;
  }
}